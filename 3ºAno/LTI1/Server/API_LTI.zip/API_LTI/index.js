const express = require('express');
const fs = require('fs');
const fse = require('fs-extra');
const zipper = require('zip-local');
const rimraf = require("rimraf");
const cors = require('cors');
const multer = require('multer');

const app = express();
app.use(cors());

var storage =   multer.diskStorage({
    destination: function (req, file, callback) {
      callback(null, '../Cloud');
    },
    filename: function (req, file, callback) {
        callback(null, file.originalname);
    }
  });
var upload = multer({ storage : storage}).single('userFile');

app.use(express.json());

let lastnewfile='';
let lastnew=false;
let lastdelfile='';
let lastdel=false;

app.get('/', (req, res) => {
    res.send('API -> LTI I');
});

app.get('/api/files', (req, res) => { // Retorna todos os nomes dos ficheiros na pasta
    const filesinfo = [];
    const files = fs.readdirSync('../Cloud');
    if(files.length==0){
        const nofiles = {
            files: 'No files on cloud.'
        }
        res.send(nofiles);
    }else{
        files.forEach(function(entry){
            fs.stat('../Cloud/'+entry, (err, stats) =>{
                //console.log(stats);
                var date = new Date(stats.ctime);
                if(stats.size<1000){
                    stats.size.toString();
                    stats.size = stats.size + ' bytes';
                }
                if(stats.size>=1000 && stats.size <1000000){
                    stats.size = stats.size/1000;
                    stats.size.toString();
                    stats.size = stats.size + ' Kbytes';
                }
                if(stats.size>=1000000 && stats.size <=1000000000){
                    stats.size = stats.size/1000000;
                    stats.size.toString();
                    stats.size = stats.size + ' Mbytes';
                }
                const fileinfo = {
                    name: entry,
                    createdAt: date.toUTCString(),
                    size: stats.size
                }
                filesinfo.push(fileinfo);
                if(filesinfo.length==files.length){
                    res.send(filesinfo); 
                }
            });
        }); 
    }
});

app.get('/api/backups', (req, res) => { // Retorna array com o nome de todos os backups
    const backups = fs.readdirSync('../Backup');
    console.log(backups)
    if(backups.length==0){
        const nobackups = {
            backup: 'No backups available.'
        }
        res.send(nobackups);
    }else{
        res.send(backups);
    }
});

app.get('/api/backup/:name', (req, res) => { // Retorna o backup pedido
    const backups = fs.readdirSync('../Backup');
    var n = backups.includes(req.params.name); // Retorna true se existe
    if(n){ // Se existe esse backup
        const buffer = fs.readFileSync('../Backup/'+req.params.name);
        res.send(buffer); // Enviar o backup
    }else{
        res.status(404).send('There is no backup for "'+req.params.name+'"');
    }   
});

app.get('/api/newfile', (req,res) => {
    if(lastnew==true){
        lastnew=false;
        res.send(lastnewfile); 
    }else{
        res.send(lastnew);
    }
});

app.get('/api/deletedfile', (req,res) => {
    if(lastdel==true){
        lastdel=false;
        res.send(lastdelfile); 
    }else{
        res.send(lastdel);
    }
});

app.get('/api/file/:name', (req, res) => { // Retorna o ficheiro com o nome pedido
    const files = fs.readdirSync('../Cloud');
    var n = files.includes(req.params.name); // Retorna true se existe
    if(n){ // Se existe esse ficheiro
        const buffer = fs.readFileSync('../Cloud/'+req.params.name);
        res.send(buffer); // Enviar o ficheiro
    }else{
        res.status(404).send('There is no file with such name.');
    }   
});

function sleep (time) {
    return new Promise((resolve) => setTimeout(resolve, time));
  }

app.post('/api/file', (req, res) => {

    console.log(req.file)

    upload(req,res,function(err) {
        if(err) {
            return res.end("Error uploading file.");
        }
        lastnewfile = req.file.filename;
        lastnew=true;
        res.end(true);
    });  

    const obj = {
        true: true
    }
    res.send(obj);
});

app.delete('/api/file/:name', (req, res) =>{
    const files = fs.readdirSync('../Cloud');
    var n = files.includes(req.params.name); // Retorna true se existe
    if(n){ // Se existe esse ficheiro
        const actualdate = new Date();
        fse.copy('../Cloud', '../Backup/'+actualdate, function (err) { // Criar pasta backup
            if(err){
                const notdel = {
                    name: req.params.name,
                    deleted: false,
                    message: 'Not deleted, backup failed'
                }
                res.send(notdel)
            }else{ // Se criar o backup com sucesso, zippar pasta, e eliminar ficheiro
                zipper.zip('../Backup/'+actualdate, function(error, zipped) {
                    if(!error) {
                        zipped.compress(); // compress before exporting
                        zipped.save('../Backup/'+actualdate+'.zip', function(error) { // Guardar ficheiro .zip
                            if(!error) {
                                rimraf("../Backup/"+actualdate, function () { console.log("done"); });
                            }
                        });
                    }
                });

                fs.unlinkSync('../Cloud/'+req.params.name)
                lastdelfile = req.params.name;
                lastdel=true;
                const deleted = {
                    name: req.params.name,
                    deleted: true
                }
                res.send(deleted);
            }
        });
    }else{
        const deleted = {
            name: req.params.name,
            deleted: false,
            message: 'File does not exist'
        }
        res.send(deleted);
    }
});

const port = process.env.PORT || 11111;
app.listen(port, () => console.log(`Listening on port ${port}...`));