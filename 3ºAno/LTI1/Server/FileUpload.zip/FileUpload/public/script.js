var fileArray = [{
    name: String,
    createdAt: Date,
    size: String
}]

let currentFiles = [{
    name: String,
    createdAt: Date,
    size: String
}]

const ip = "http://192.168.43.194:11111";
//const ip = "http://localhost:11111"

$(document).ready(function () { //quando a pagina estiver pronta
    const customLabel = document.getElementById("inputGroupFile02");
    const inputForm = document.getElementById("userFile");
    var upload = false;

    window.setInterval(function () {
        console.log("hey");
      //  if (upload == false) {
            $.ajax({
                type: 'GET',
                url: ip + '/api/files',
                contentType: 'application/json',
                success: function (response) {

                    if (currentFiles.length != response.length) {
                        location.reload();
                    }

                }
            })

       // }

    }, 2000);

    inputForm.addEventListener("change", function () { //mudar placeholder quando o ficheiro é selecionado
        if (inputForm.value) {
            customLabel.innerHTML = inputForm.value.match(/[\/\\]([\w\d\s\.\-\(\)]+)$/)[1];
        }
    })

    $("#formulario").submit(function (event) {
        event.preventDefault();
       
        var form = new FormData;
        form.append('userFile', userFile.files[0]);
        console.log(form);
        if (!userFile.files[0]) {
            alert("Selecione um ficheiro valido")
        }
        else {
            upload=true;
            $.ajax({
                type: 'POST',
                url: ip + '/api/file',
                contentType: false,
                processData: false,
                data: form,
                success: function (response) {
                    if (response) {
                        alert("O seu ficheiro fez upload com sucesso!");
                        upload=false;
                        location.reload();
                    }
                }
            })

        }

    })

    dropContainer.ondragover = dropContainer.ondragenter = function (evt) {
        evt.preventDefault();
    };

    dropContainer.ondrop = function (evt) {
        evt.preventDefault();
        //upload=true;
        //userFile.files = evt.dataTransfer.files;
        var form = new FormData;
        form.append('userFile', evt.dataTransfer.files[0]);
        console.log(form);
        
        $.ajax({
            type: 'POST',
            url: ip + '/api/file',
            data: form,
            contentType: false,
            processData: false,
            success: function (response) {
                console.log(response);
                alert("O seu ficheiro fez upload com sucesso!");
               // upload=false;
                location.reload();
            }
        })
    };


    //mostrar nome e data do ficheiro
    $.ajax({
        type: 'GET',
        url: ip + '/api/files',
        contentType: 'application/json',
        success: function (response) {
            fileArray = response;
            currentFiles = fileArray;
            for (var i = 0; i < fileArray.length; i++) {

                var tbodyEl = $('tbody');
                var fileName = fileArray[i].name;
                tbodyEl.append("<tr><th style='text-align:center' scope='row'>" + (i + 1) + "</th><td style='text-align:center'>" + fileName + "</td><td style='text-align:center'>" + fileArray[i].createdAt + "</td><td style='text-align:center' >" + fileArray[i].size + "</td><td><button class='btnDelete' type='button' deleteId='" + fileName + "' > Delete </button></td><td><td><button class='btnDownload' type='button' downloadId='" + fileName + "' >Download</button></td></tr>");
            }
        }
    });

    //apagar ficheiro
    $(document).on("click", ".btnDelete", function () {
        $.ajax({
            type: 'DELETE',
            url: ip + '/api/file/' + $(this).attr('deleteId'),
            success: function (response) {
                if (response.deleted) {
                    alert("O seu ficheiro foi apagado com sucesso!");
                    location.reload();
                }
            }
        })
    })

    $(document).on("click", ".btnDownload", function () { //download do ficheiro
        /* $.ajax({
             type:'GET',
             url:'http://localhost:1337/api/file/' + $(this).attr('downloadId'),
             success: function(response){
                 console.log(response);
             }
         })*/
        window.open(ip + "/api/file/" + $(this).attr('downloadId'));
        alert("O seu ficheiro foi descarregado com sucesso!");
    })

})








