var arrayNames = [{
    name: String
}
]

const ip = "http://192.168.43.194:11111"
//const ip = "http://localhost:11111"

$(document).ready(function () {
    console.log("HEY");
    $.ajax({
        type: 'GET',
        url: ip + '/api/backups',
        contentType: 'application/json',
        success: function (response) {
            arrayNames = response;
            var tbodyEl = $('tbody');
            console.log(arrayNames);
            for (var i = 0; i < arrayNames.length; i++) {
                var fileName = arrayNames[i];
                tbodyEl.append("<tr><th style='text-align:center' scope='row'>" + (i + 1) + "</th><td style='text-align:center'>" + fileName + "</td><td></button></td><td><td><button class='btnDownload' type='button' downloadId='" + fileName + "' >Download</button></td></tr>");

            }


        }

    })

    $(document).on("click", ".btnDownload", function () { //download do ficheiro
        /* $.ajax({
             type:'GET',
             url:'http://localhost:1337/api/file/' + $(this).attr('downloadId'),
             success: function(response){
                 console.log(response);
             }
         })*/
        window.open(ip + "/api/backup/" + $(this).attr('downloadId'));
        alert("O seu ficheiro foi descarregado com sucesso!");
    })


})

