const express = require('express');
var app = express();
const http = require('http');
const PORT= 8078;
const cors = require('cors');
http.Server(app).listen(PORT); // make server listen on port 80


console.log("Server Started at port" + PORT);

app.use(cors());

app.use("/public", express.static(process.cwd() + '/public'));



app.route('/public/index').get((req, res)=>{
    res.sendFile(process.cwd() + "/public/index.html");
})

app.route('/').get((req, res)=>{
    res.sendFile(process.cwd() + "/public/home.html");
})

app.route('/public/backup').get((req, res)=>{
    res.sendFile(process.cwd() + "/public/backup.html");
})

